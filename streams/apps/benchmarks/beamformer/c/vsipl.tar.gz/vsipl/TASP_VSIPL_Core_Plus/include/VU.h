/* Created RJudd     */
/* SPAWARSYSCEN D881 */
/* These functions are for testing and general utility */
/* They are not designed to be robust or useful        */
/* for anything except quick and dirty analysis        */
/* they may not be complete. I only wrote what I       */
/* needed for the task at hand                         */
#ifndef _vsip_VU_h
#define _vsip_VU_h
/* read an "indexed" asci data file                   */ 
/* format for vector <index> <value>                  */
/* for matrix <row_index> <col_index> <value>         */
/* for tensor <z_index> <y_index> <x_index> <value>   */
/* for complex <value> is <<real_value> <imag_value>> */
void VU_mreadf_f( FILE*, vsip_mview_f*);
void VU_cmreadf_f( FILE*, vsip_cmview_f*);
void VU_vreadf_f( FILE*, vsip_vview_f*);
void VU_cvreadf_f( FILE*, vsip_cvview_f*);
void VU_mreadf_d( FILE*, vsip_mview_d*);
void VU_cmreadf_d( FILE*, vsip_cmview_d*);
void VU_vreadf_d( FILE*, vsip_vview_d*);
void VU_cvreadf_d( FILE*, vsip_cvview_d*);

/* print something easy to past into matlab */ 
void VU_vprintm_f( char*, vsip_vview_f*); 
void VU_vprintm_d( char*, vsip_vview_d*);
void VU_cvprintm_f( char*, vsip_cvview_f*); 
void VU_cvprintm_d( char*, vsip_cvview_d*);
void VU_vprintm_i( char*, vsip_vview_i*);
void VU_vprintm_si( char*, vsip_vview_si*);

void VU_mprintm_f( char*, vsip_mview_f*); 
void VU_mprintm_d( char*, vsip_mview_d*);
void VU_cmprintm_f( char*, vsip_cmview_f*); 
void VU_cmprintm_d( char*, vsip_cmview_d*);
void VU_mprintm_i( char*, vsip_mview_i*);
void VU_mprintm_si( char*, vsip_mview_si*);

void VU_tprintm_f( char*, vsip_tview_f*); 
void VU_tprintm_d( char*, vsip_tview_d*);
void VU_ctprintm_f( char*, vsip_ctview_f*);
void VU_ctprintm_d( char*, vsip_ctview_d*);
void VU_tprintm_i( char*, vsip_tview_i*);
void VU_tprintm_si( char*, vsip_tview_si*);

void VU_vprintm_vi( char*, vsip_vview_vi*); 
void VU_vprintm_mi( char*, vsip_vview_mi*); 

/* Note no format needed for boolean print */
/* 1 (true) or 0 (false) printed           */
void VU_vprintm_bl( vsip_vview_bl*);
void VU_mprintm_bl( vsip_vview_bl*);

#endif /*_vsip_VU_h */
