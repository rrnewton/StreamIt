/* Created RJudd September 23, 2000 */
/* SPAWARSYSCEN D857                */
/**********************************************************************
// For TASP VSIPL Documentation and Code neither the United States    /
// Government, the United States Navy, nor any of their employees,    /
// makes any warranty, express or implied, including the warranties   /
// of merchantability and fitness for a particular purpose, or        /
// assumes any legal liability or responsibility for the accuracy,    /
// completeness, or usefulness of any information, apparatus,         /
// product, or process disclosed, or represents that its use would    /
// not infringe privately owned rights                                /
**********************************************************************/
/* $Id: vsip_cmput_f.c,v 1.1 1999/12/04 02:44:13 judd Exp judd $ */

#include<vsip.h>
#include<vsip_cmviewattributes_f.h>

void (vsip_cmput_f)(
  const vsip_cmview_f *v,
  vsip_index row, 
  vsip_index col, 
  vsip_cscalar_f s) {
   vsip_stride str = (v->offset + 
                       row * v->col_stride + col * v->row_stride) *
                         v->block->cstride;
   *(v->block->R->array + str) = s.r;
   *(v->block->I->array + str) = s.i;
   return;
}
