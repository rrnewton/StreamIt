/* Created RJudd September 17, 2000 */
/* SPAWARSYSCEN D857                */
/**********************************************************************
// For TASP VSIPL Documentation and Code neither the United States    /
// Government, the United States Navy, nor any of their employees,    /
// makes any warranty, express or implied, including the warranties   /
// of merchantability and fitness for a particular purpose, or        /
// assumes any legal liability or responsibility for the accuracy,    /
// completeness, or usefulness of any information, apparatus,         /
// product, or process disclosed, or represents that its use would    /
// not infringe privately owned rights                                /
**********************************************************************/
/* $Id: vsip_cblockfind_f.c,v 1.1 1999/12/04 02:47:43 judd Exp judd $ */

#include<vsip.h>
#include<vsip_cblockattributes_f.h>

void (vsip_cblockfind_f)(
  const vsip_cblock_f* b,
  vsip_scalar_f* *Rp,
  vsip_scalar_f* *Ip) {
   if(b->admit == VSIP_RELEASED_BLOCK){
       if(b->cstride == 1){
           *Rp = b->R->array;
           *Ip = b->I->array;
       } else {
           *Rp = b->R->array;
           *Ip = (vsip_scalar_f*)NULL;
       }
   } else {
       *Rp = (vsip_scalar_f*)NULL;
       *Ip = (vsip_scalar_f*)NULL;
   }
   return;
}
