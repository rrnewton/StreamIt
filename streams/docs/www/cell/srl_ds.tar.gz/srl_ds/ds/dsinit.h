#ifndef _DS_INIT_H_
#define _DS_INIT_H_

#ifndef __SPU__

#include "filterdefs.h"
#include "ds.h"

#define CHANNEL_INTERFACE

#endif

#endif
