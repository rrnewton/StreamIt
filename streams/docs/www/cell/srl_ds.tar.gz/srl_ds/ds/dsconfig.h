#ifndef _DS_CONFIG_H_
#define _DS_CONFIG_H_

#define PRINT_SCHEDULE  0
#define PRINT_BUFFERING 0

#endif
