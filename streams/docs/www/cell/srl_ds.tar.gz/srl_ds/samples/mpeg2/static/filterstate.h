#ifndef _FILTER_STATE_H_
#define _FILTER_STATE_H_

typedef struct {
  int PMV__298__337__392__628[2][2][2];
} QWORD_ALIGNED FILTER_2_STATE;

#endif
