#include "filterdefs.h"

#define FILTER_NAME     3
#define ITEM_TYPE       int
#define NUM_INPUT_TAPES 2
#define JOINER_RATES    {64, 11}

#include "rrjoiner.h"
