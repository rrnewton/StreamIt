#include "filterdefs.h"

#define FILTER_NAME       0
#define ITEM_TYPE         int
#define NUM_OUTPUT_TAPES  2
#define SPLITTER_RATES    {384, 19}

#include "rrsplitter.h"
