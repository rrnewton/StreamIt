/* Created RJudd September 16, 2000 */
/* SPAWARSYSCEN D857                */
/**********************************************************************
// For TASP VSIPL Documentation and Code neither the United States    /
// Government, the United States Navy, nor any of their employees,    /
// makes any warranty, express or implied, including the warranties   /
// of merchantability and fitness for a particular purpose, or        /
// assumes any legal liability or responsibility for the accuracy,    /
// completeness, or usefulness of any information, apparatus,         /
// product, or process disclosed, or represents that its use would    /
// not infringe privately owned rights                                /
**********************************************************************/
/* $Id: vsip_cblockbind_f.c,v 1.2 1999/12/04 02:47:42 judd Exp judd $ */

#include<vsip.h>
#include<vsip_cblockattributes_f.h>
#include<vsip_blockattributes_f.h>

vsip_cblock_f* (vsip_cblockbind_f)(
  vsip_scalar_f* Rp,
  vsip_scalar_f* Ip,
  size_t N, 
  vsip_memory_hint h) {
  vsip_cblock_f* b = (vsip_cblock_f*)malloc(sizeof(vsip_cblock_f));
  { 
    if(b != (vsip_cblock_f*)NULL){
        b->kind     = VSIP_USER_BLOCK;
        b->admit    = VSIP_RELEASED_BLOCK;
        b->markings = VSIP_VALID_STRUCTURE_OBJECT;
        b->bindings = 0;
        if(Ip == (vsip_scalar_f*)NULL){ /* interleaved */
           b->cstride = 2;
           b->R = vsip_blockbind_f(Rp,N,h);
           b->I = (vsip_block_f*)malloc(sizeof(vsip_block_f));
           if((b->R == (vsip_block_f*)NULL) || (b->I == (vsip_block_f*)NULL)){
              free((void *)b->R); 
              free((void *)b->I);
              free((void *)b);
              b = (vsip_cblock_f*)NULL;
           } else {
              b->R->kind = VSIP_DERIVED_BLOCK;
              b->R->rstride = b->cstride;
              b->R->parent = b;
              *b->I = *b->R;
              b->I->array++;
           }         
        } else { /* split */
           b->cstride = 1;
           b->R = vsip_blockbind_f(Rp,N,h);
           b->I = vsip_blockbind_f(Ip,N,h);
           if((b->R == (vsip_block_f*)NULL) || (b->I == (vsip_block_f*)NULL)){
              free((void *)b->R); 
              free((void *)b->I);
              free((void *)b);
              b = (vsip_cblock_f*)NULL;
           } else {
              b->R->kind = VSIP_DERIVED_BLOCK;
              b->R->parent = b;
              b->I->kind = VSIP_DERIVED_BLOCK;
              b->I->parent = b;
           }
        }
      }
    }
    return b;
 }
