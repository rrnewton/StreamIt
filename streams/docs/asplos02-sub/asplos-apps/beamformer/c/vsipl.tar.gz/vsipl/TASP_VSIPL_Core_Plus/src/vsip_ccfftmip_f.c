/* Created by RJudd January 7, 1999 */
/* SPAWARSYSCEN D881 */
/**********************************************************************
// For TASP VSIPL Documentation and Code neither the United States    /
// Government, the United States Navy, nor any of their employees,    /
// makes any warranty, express or implied, including the warranties   /
// of merchantability and fitness for a particular purpose, or        /
// assumes any legal liability or responsibility for the accuracy,    /
// completeness, or usefulness of any information, apparatus,         /
// product, or process disclosed, or represents that its use would    /
// not infringe privately owned rights                                /
**********************************************************************/
/* $Id: vsip_ccfftmip_f.c,v 1.1 1999/12/02 18:53:22 judd Exp judd $ */
#include<vsip.h>
#include<vsip_cmviewattributes_f.h>
#include<vsip_cvviewattributes_f.h>
#include<vsip_fftmattributes_f.h>
#include"VI_ftm_f.h"


void vsip_ccfftmip_f(const vsip_fftm_f *Offt, 
                    const vsip_cmview_f *y)
{
     vsip_fftm_f Nfft = *Offt;
     vsip_fftm_f *fft = &Nfft;
     VI_ccfftmip_f(fft,y);
}

