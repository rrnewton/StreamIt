/* Created RJudd September 16, 2000 */
/* SPAWARSYSCEN D857                */
/**********************************************************************
// For TASP VSIPL Documentation and Code neither the United States    /
// Government, the United States Navy, nor any of their employees,    /
// makes any warranty, express or implied, including the warranties   /
// of merchantability and fitness for a particular purpose, or        /
// assumes any legal liability or responsibility for the accuracy,    /
// completeness, or usefulness of any information, apparatus,         /
// product, or process disclosed, or represents that its use would    /
// not infringe privately owned rights                                /
**********************************************************************/
/* $Id: vsip_cblockcreate_f.c,v 1.3 1999/11/14 18:15:40 judd Exp judd $ */

#include<vsip.h>
#include<vsip_cblockattributes_f.h>

vsip_cblock_f* (vsip_cblockcreate_f)(
   size_t N, 
   vsip_memory_hint h) {
  vsip_cblock_f* b = (vsip_cblock_f*)malloc(sizeof(vsip_cblock_f));
  if(b != NULL){
      b->kind     = VSIP_VSIPL_BLOCK;
      b->admit    = VSIP_ADMITTED_BLOCK;
      b->markings = VSIP_VALID_STRUCTURE_OBJECT;
      b->size     = N;   /* size in complex elements         */
      b->cstride  = 2;   /* native block are interleaved     */
      b->bindings = 0;
      b->R = vsip_blockcreate_f(2 * N,h);
      b->I = (vsip_block_f*)malloc(sizeof(vsip_block_f));
      if((b->R == NULL) || (b->I == NULL)){
          vsip_blockdestroy_f(b->R);
          free((void *)b->I);
          free((void *)b);
          b = (vsip_cblock_f*)NULL;
      } else {
          /* modifiy real                                       */
          b->R->kind       = VSIP_DERIVED_BLOCK;
          b->R->rstride = b->cstride;
          b->R->size    = N;  /* size in real elements          */
          b->R->parent  = b;
          /* initiate imaginary                                 */
          /* same as real except array data pointer one greater */
          *b->I = *b->R;
          b->I->array++;
      }
  }    
  return b;
}
