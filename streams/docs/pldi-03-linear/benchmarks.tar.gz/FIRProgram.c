/*
*/
#include "streamit.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct Complex {
  float imag;
  float real;
} Complex;
typedef struct FloatSource_1 {
  stream_context* context;
  tape inTape;
  tape outTape;
  int idx;
  float* inputs;
} _FloatSource_1, *FloatSource_1;
typedef struct LowPassFilter_1 {
  stream_context* context;
  tape inTape;
  tape outTape;
  int N;
  float cutoffFreq;
  float g;
  float* h;
} _LowPassFilter_1, *LowPassFilter_1;
typedef struct FloatPrinter_1 {
  stream_context* context;
  tape inTape;
  tape outTape;
} _FloatPrinter_1, *FloatPrinter_1;
typedef struct FIRProgram_1 {
  stream_context* context;
  tape inTape;
  tape outTape;
  FloatSource_1 child_0;
  LowPassFilter_1 child_1;
  FloatPrinter_1 child_2;
} _FIRProgram_1, *FIRProgram_1;
typedef struct Main {
  int __dummy__;
} _Main, *Main;
int main(int argc, char **argv);
void hierarchical_work_3(FIRProgram_1 data);
void hierarchical_work_2(FIRProgram_1 data);
void hierarchical_work_1(FIRProgram_1 data);
void FloatSource_1_work(FloatSource_1 data);
void FloatSource_1_init(FloatSource_1 data);
void LowPassFilter_1_work(LowPassFilter_1 data);
void LowPassFilter_1_init(LowPassFilter_1 data);
void FloatPrinter_1_work(FloatPrinter_1 data);
void FloatPrinter_1_init(FloatPrinter_1 data);
void FIRProgram_1_init(FIRProgram_1 data);
int main(int argc, char **argv) {
  FIRProgram_1 data = malloc(sizeof(_FIRProgram_1));
  data->context = create_context(data);
  FIRProgram_1_init(data);
  connect_tapes(data->context);
  hierarchical_work_3((data));
  streamit_run(data->context, argc, argv);
  return 0;
}

void hierarchical_work_3(FIRProgram_1 data) {
  hierarchical_work_2((data));
}

void hierarchical_work_2(FIRProgram_1 data) {
  {
    int streamItVar1 = 0;

    for (
    ; (streamItVar1 < 255); (streamItVar1++)) {
FloatSource_1_work(((data)->child_0));
    }
  }
}

void hierarchical_work_1(FIRProgram_1 data) {
  FloatSource_1_work(((data)->child_0));
  LowPassFilter_1_work(((data)->child_1));
  FloatPrinter_1_work(((data)->child_2));
}

void FloatSource_1_work(FloatSource_1 data) {
  VARS_DEFAULTB();LOCALIZE_DEFAULTB(((data)->context));
  (PUSH_DEFAULTB(float, (((data)->inputs)[((data)->idx)])));
  (((data)->idx) = ((((data)->idx) + 1) % 16));
  UNLOCALIZE_DEFAULTB(((data)->context));
}

void FloatSource_1_init(FloatSource_1 data) {
  int i;

  (((data)->inputs) = calloc(16, sizeof(float)));
  {
    (i = 0);
    {
      ((((data)->inputs)[0]) = 0);
    }
    {
      ((((data)->inputs)[1]) = 1);
    }
    {
      ((((data)->inputs)[2]) = 2);
    }
    {
      ((((data)->inputs)[3]) = 3);
    }
    {
      ((((data)->inputs)[4]) = 4);
    }
    {
      ((((data)->inputs)[5]) = 5);
    }
    {
      ((((data)->inputs)[6]) = 6);
    }
    {
      ((((data)->inputs)[7]) = 7);
    }
    {
      ((((data)->inputs)[8]) = 8);
    }
    {
      ((((data)->inputs)[9]) = 9);
    }
    {
      ((((data)->inputs)[10]) = 10);
    }
    {
      ((((data)->inputs)[11]) = 11);
    }
    {
      ((((data)->inputs)[12]) = 12);
    }
    {
      ((((data)->inputs)[13]) = 13);
    }
    {
      ((((data)->inputs)[14]) = 14);
    }
    {
      ((((data)->inputs)[15]) = 15);
    }
    (i = 16);
  }

  ;
  (((data)->idx) = 0);
  set_stream_type(((data)->context), FILTER);
  set_push(((data)->context), 1);
  set_peek(((data)->context), 0);
  set_pop(((data)->context), 0);
  set_work(((data)->context), (work_fn)FloatSource_1_work);
}

void LowPassFilter_1_work(LowPassFilter_1 data) {
  VARS_DEFAULTB();LOCALIZE_DEFAULTB(((data)->context));
  float sum;
  int i;

  (sum = ((float)0.0));
  for ((i = 0); (i < ((data)->N)); (i++)) {
{
      (sum = (sum + ((((data)->h)[i]) * (PEEK_DEFAULTB(float, i)))));
    }
  }

  ;
  (PUSH_DEFAULTB(float, sum));
  (POP_DEFAULTB( float));
  UNLOCALIZE_DEFAULTB(((data)->context));
}

void LowPassFilter_1_init(LowPassFilter_1 data) {
  int OFFSET;
  int idx;
  int i;

  (((data)->g) = ((float)1.0));
  (((data)->cutoffFreq) = ((float)1.0471976));
  (((data)->N) = 256);
  (((data)->h) = calloc(256, sizeof(float)));
  (OFFSET = 128);
  {
    (i = 0);
    {
      (idx = 1);
      {
        ((((data)->h)[0]) = ((float)0.0021705935));
      }

      ;
    }
    {
      (idx = 2);
      {
        ((((data)->h)[1]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 3);
      {
        ((((data)->h)[2]) = ((float)-0.0022053027));
      }

      ;
    }
    {
      (idx = 4);
      {
        ((((data)->h)[3]) = ((float)-0.0022230966));
      }

      ;
    }
    {
      (idx = 5);
      {
        ((((data)->h)[4]) = ((float)2.4471536E-9));
      }

      ;
    }
    {
      (idx = 6);
      {
        ((((data)->h)[5]) = ((float)0.002259543));
      }

      ;
    }
    {
      (idx = 7);
      {
        ((((data)->h)[6]) = ((float)0.002278223));
      }

      ;
    }
    {
      (idx = 8);
      {
        ((((data)->h)[7]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 9);
      {
        ((((data)->h)[8]) = ((float)-0.002316508));
      }

      ;
    }
    {
      (idx = 10);
      {
        ((((data)->h)[9]) = ((float)-0.002336142));
      }

      ;
    }
    {
      (idx = 11);
      {
        ((((data)->h)[10]) = ((float)-1.12217675E-8));
      }

      ;
    }
    {
      (idx = 12);
      {
        ((((data)->h)[11]) = ((float)0.0023764092));
      }

      ;
    }
    {
      (idx = 13);
      {
        ((((data)->h)[12]) = ((float)0.002397083));
      }

      ;
    }
    {
      (idx = 14);
      {
        ((((data)->h)[13]) = ((float)7.944424E-9));
      }

      ;
    }
    {
      (idx = 15);
      {
        ((((data)->h)[14]) = ((float)-0.0024395015));
      }

      ;
    }
    {
      (idx = 16);
      {
        ((((data)->h)[15]) = ((float)-0.0024612998));
      }

      ;
    }
    {
      (idx = 17);
      {
        ((((data)->h)[16]) = ((float)-4.489926E-9));
      }

      ;
    }
    {
      (idx = 18);
      {
        ((((data)->h)[17]) = ((float)0.002506035));
      }

      ;
    }
    {
      (idx = 19);
      {
        ((((data)->h)[18]) = ((float)0.0025290402));
      }

      ;
    }
    {
      (idx = 20);
      {
        ((((data)->h)[19]) = ((float)8.4351265E-10));
      }

      ;
    }
    {
      (idx = 21);
      {
        ((((data)->h)[20]) = ((float)-0.0025762997));
      }

      ;
    }
    {
      (idx = 22);
      {
        ((((data)->h)[21]) = ((float)-0.0026006147));
      }

      ;
    }
    {
      (idx = 23);
      {
        ((((data)->h)[22]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 24);
      {
        ((((data)->h)[23]) = ((float)0.0026506179));
      }

      ;
    }
    {
      (idx = 25);
      {
        ((((data)->h)[24]) = ((float)0.0026763587));
      }

      ;
    }
    {
      (idx = 26);
      {
        ((((data)->h)[25]) = ((float)1.6716138E-8));
      }

      ;
    }
    {
      (idx = 27);
      {
        ((((data)->h)[26]) = ((float)-0.0027293512));
      }

      ;
    }
    {
      (idx = 28);
      {
        ((((data)->h)[27]) = ((float)-0.0027566475));
      }

      ;
    }
    {
      (idx = 29);
      {
        ((((data)->h)[28]) = ((float)-1.3108724E-8));
      }

      ;
    }
    {
      (idx = 30);
      {
        ((((data)->h)[29]) = ((float)0.0028128922));
      }

      ;
    }
    {
      (idx = 31);
      {
        ((((data)->h)[30]) = ((float)0.0028419027));
      }

      ;
    }
    {
      (idx = 32);
      {
        ((((data)->h)[31]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 33);
      {
        ((((data)->h)[32]) = ((float)-0.0029017227));
      }

      ;
    }
    {
      (idx = 34);
      {
        ((((data)->h)[33]) = ((float)-0.0029325993));
      }

      ;
    }
    {
      (idx = 35);
      {
        ((((data)->h)[34]) = ((float)-5.1956843E-9));
      }

      ;
    }
    {
      (idx = 36);
      {
        ((((data)->h)[35]) = ((float)0.0029963464));
      }

      ;
    }
    {
      (idx = 37);
      {
        ((((data)->h)[36]) = ((float)0.0030292897));
      }

      ;
    }
    {
      (idx = 38);
      {
        ((((data)->h)[37]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 39);
      {
        ((((data)->h)[38]) = ((float)-0.0030973493));
      }

      ;
    }
    {
      (idx = 40);
      {
        ((((data)->h)[39]) = ((float)-0.0031325584));
      }

      ;
    }
    {
      (idx = 41);
      {
        ((((data)->h)[40]) = ((float)3.8088084E-9));
      }

      ;
    }
    {
      (idx = 42);
      {
        ((((data)->h)[41]) = ((float)0.0032053986));
      }

      ;
    }
    {
      (idx = 43);
      {
        ((((data)->h)[42]) = ((float)0.0032431171));
      }

      ;
    }
    {
      (idx = 44);
      {
        ((((data)->h)[43]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 45);
      {
        ((((data)->h)[44]) = ((float)-0.0033212588));
      }

      ;
    }
    {
      (idx = 46);
      {
        ((((data)->h)[45]) = ((float)-0.0033617653));
      }

      ;
    }
    {
      (idx = 47);
      {
        ((((data)->h)[46]) = ((float)-1.5834326E-8));
      }

      ;
    }
    {
      (idx = 48);
      {
        ((((data)->h)[47]) = ((float)0.0034458085));
      }

      ;
    }
    {
      (idx = 49);
      {
        ((((data)->h)[48]) = ((float)0.0034894247));
      }

      ;
    }
    {
      (idx = 50);
      {
        ((((data)->h)[49]) = ((float)1.12217675E-8));
      }

      ;
    }
    {
      (idx = 51);
      {
        ((((data)->h)[50]) = ((float)-0.0035800475));
      }

      ;
    }
    {
      (idx = 52);
      {
        ((((data)->h)[51]) = ((float)-0.0036271624));
      }

      ;
    }
    {
      (idx = 53);
      {
        ((((data)->h)[52]) = ((float)-6.2402052E-9));
      }

      ;
    }
    {
      (idx = 54);
      {
        ((((data)->h)[53]) = ((float)0.0037251874));
      }

      ;
    }
    {
      (idx = 55);
      {
        ((((data)->h)[54]) = ((float)0.0037762376));
      }

      ;
    }
    {
      (idx = 56);
      {
        ((((data)->h)[55]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 57);
      {
        ((((data)->h)[56]) = ((float)-0.0038825925));
      }

      ;
    }
    {
      (idx = 58);
      {
        ((((data)->h)[57]) = ((float)-0.0039380733));
      }

      ;
    }
    {
      (idx = 59);
      {
        ((((data)->h)[58]) = ((float)5.0224576E-9));
      }

      ;
    }
    {
      (idx = 60);
      {
        ((((data)->h)[59]) = ((float)0.0040538865));
      }

      ;
    }
    {
      (idx = 61);
      {
        ((((data)->h)[60]) = ((float)0.0041144025));
      }

      ;
    }
    {
      (idx = 62);
      {
        ((((data)->h)[61]) = ((float)2.5373932E-8));
      }

      ;
    }
    {
      (idx = 63);
      {
        ((((data)->h)[62]) = ((float)-0.004240992));
      }

      ;
    }
    {
      (idx = 64);
      {
        ((((data)->h)[63]) = ((float)-0.0043072617));
      }

      ;
    }
    {
      (idx = 65);
      {
        ((((data)->h)[64]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 66);
      {
        ((((data)->h)[65]) = ((float)0.0044462048));
      }

      ;
    }
    {
      (idx = 67);
      {
        ((((data)->h)[66]) = ((float)0.0045190905));
      }

      ;
    }
    {
      (idx = 68);
      {
        ((((data)->h)[67]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 69);
      {
        ((((data)->h)[68]) = ((float)-0.004672276));
      }

      ;
    }
    {
      (idx = 70);
      {
        ((((data)->h)[69]) = ((float)-0.0047528436));
      }

      ;
    }
    {
      (idx = 71);
      {
        ((((data)->h)[70]) = ((float)-7.944424E-9));
      }

      ;
    }
    {
      (idx = 72);
      {
        ((((data)->h)[71]) = ((float)0.0049225693));
      }

      ;
    }
    {
      (idx = 73);
      {
        ((((data)->h)[72]) = ((float)0.005012086));
      }

      ;
    }
    {
      (idx = 74);
      {
        ((((data)->h)[73]) = ((float)8.4351265E-10));
      }

      ;
    }
    {
      (idx = 75);
      {
        ((((data)->h)[74]) = ((float)-0.0052012093));
      }

      ;
    }
    {
      (idx = 76);
      {
        ((((data)->h)[75]) = ((float)-0.005301241));
      }

      ;
    }
    {
      (idx = 77);
      {
        ((((data)->h)[76]) = ((float)-1.6716138E-8));
      }

      ;
    }
    {
      (idx = 78);
      {
        ((((data)->h)[77]) = ((float)0.0055132858));
      }

      ;
    }
    {
      (idx = 79);
      {
        ((((data)->h)[78]) = ((float)0.0056258147));
      }

      ;
    }
    {
      (idx = 80);
      {
        ((((data)->h)[79]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 81);
      {
        ((((data)->h)[80]) = ((float)-0.005865202));
      }

      ;
    }
    {
      (idx = 82);
      {
        ((((data)->h)[81]) = ((float)-0.005992712));
      }

      ;
    }
    {
      (idx = 83);
      {
        ((((data)->h)[82]) = ((float)-8.4351276E-10));
      }

      ;
    }
    {
      (idx = 84);
      {
        ((((data)->h)[83]) = ((float)0.0062650926));
      }

      ;
    }
    {
      (idx = 85);
      {
        ((((data)->h)[84]) = ((float)0.006410803));
      }

      ;
    }
    {
      (idx = 86);
      {
        ((((data)->h)[85]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 87);
      {
        ((((data)->h)[86]) = ((float)-0.0067235194));
      }

      ;
    }
    {
      (idx = 88);
      {
        ((((data)->h)[87]) = ((float)-0.006891608));
      }

      ;
    }
    {
      (idx = 89);
      {
        ((((data)->h)[88]) = ((float)-1.12217675E-8));
      }

      ;
    }
    {
      (idx = 90);
      {
        ((((data)->h)[89]) = ((float)0.0072543286));
      }

      ;
    }
    {
      (idx = 91);
      {
        ((((data)->h)[90]) = ((float)0.007450398));
      }

      ;
    }
    {
      (idx = 92);
      {
        ((((data)->h)[91]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 93);
      {
        ((((data)->h)[92]) = ((float)-0.007876117));
      }

      ;
    }
    {
      (idx = 94);
      {
        ((((data)->h)[93]) = ((float)-0.0081077805));
      }

      ;
    }
    {
      (idx = 95);
      {
        ((((data)->h)[94]) = ((float)-2.5373932E-8));
      }

      ;
    }
    {
      (idx = 96);
      {
        ((((data)->h)[95]) = ((float)0.008614508));
      }

      ;
    }
    {
      (idx = 97);
      {
        ((((data)->h)[96]) = ((float)0.008892397));
      }

      ;
    }
    {
      (idx = 98);
      {
        ((((data)->h)[97]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 99);
      {
        ((((data)->h)[98]) = ((float)-0.009505662));
      }

      ;
    }
    {
      (idx = 100);
      {
        ((((data)->h)[99]) = ((float)-0.009845168));
      }

      ;
    }
    {
      (idx = 101);
      {
        ((((data)->h)[100]) = ((float)-8.4351265E-10));
      }

      ;
    }
    {
      (idx = 102);
      {
        ((((data)->h)[101]) = ((float)0.010602477));
      }

      ;
    }
    {
      (idx = 103);
      {
        ((((data)->h)[102]) = ((float)0.011026581));
      }

      ;
    }
    {
      (idx = 104);
      {
        ((((data)->h)[103]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 105);
      {
        ((((data)->h)[104]) = ((float)-0.011985405));
      }

      ;
    }
    {
      (idx = 106);
      {
        ((((data)->h)[105]) = ((float)-0.0125302095));
      }

      ;
    }
    {
      (idx = 107);
      {
        ((((data)->h)[106]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 108);
      {
        ((((data)->h)[107]) = ((float)0.013783224));
      }

      ;
    }
    {
      (idx = 109);
      {
        ((((data)->h)[108]) = ((float)0.014508653));
      }

      ;
    }
    {
      (idx = 110);
      {
        ((((data)->h)[109]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 111);
      {
        ((((data)->h)[110]) = ((float)-0.016215552));
      }

      ;
    }
    {
      (idx = 112);
      {
        ((((data)->h)[111]) = ((float)-0.017229032));
      }

      ;
    }
    {
      (idx = 113);
      {
        ((((data)->h)[112]) = ((float)-1.4335244E-8));
      }

      ;
    }
    {
      (idx = 114);
      {
        ((((data)->h)[113]) = ((float)0.019690307));
      }

      ;
    }
    {
      (idx = 115);
      {
        ((((data)->h)[114]) = ((float)0.021204958));
      }

      ;
    }
    {
      (idx = 116);
      {
        ((((data)->h)[115]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 117);
      {
        ((((data)->h)[116]) = ((float)-0.025060395));
      }

      ;
    }
    {
      (idx = 118);
      {
        ((((data)->h)[117]) = ((float)-0.02756644));
      }

      ;
    }
    {
      (idx = 119);
      {
        ((((data)->h)[118]) = ((float)-8.4351276E-10));
      }

      ;
    }
    {
      (idx = 120);
      {
        ((((data)->h)[119]) = ((float)0.03445805));
      }

      ;
    }
    {
      (idx = 121);
      {
        ((((data)->h)[120]) = ((float)0.039380644));
      }

      ;
    }
    {
      (idx = 122);
      {
        ((((data)->h)[121]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 123);
      {
        ((((data)->h)[122]) = ((float)-0.05513289));
      }

      ;
    }
    {
      (idx = 124);
      {
        ((((data)->h)[123]) = ((float)-0.06891611));
      }

      ;
    }
    {
      (idx = 125);
      {
        ((((data)->h)[124]) = ((float)-9.275845E-9));
      }

      ;
    }
    {
      (idx = 126);
      {
        ((((data)->h)[125]) = ((float)0.13783222));
      }

      ;
    }
    {
      (idx = 127);
      {
        ((((data)->h)[126]) = ((float)0.27566445));
      }

      ;
    }
    {
      (idx = 128);
      {
        ((((data)->h)[127]) = ((float)0.33333334));
      }

      ;
    }
    {
      (idx = 129);
      {
        ((((data)->h)[128]) = ((float)0.27566445));
      }

      ;
    }
    {
      (idx = 130);
      {
        ((((data)->h)[129]) = ((float)0.13783222));
      }

      ;
    }
    {
      (idx = 131);
      {
        ((((data)->h)[130]) = ((float)-9.275845E-9));
      }

      ;
    }
    {
      (idx = 132);
      {
        ((((data)->h)[131]) = ((float)-0.06891611));
      }

      ;
    }
    {
      (idx = 133);
      {
        ((((data)->h)[132]) = ((float)-0.05513289));
      }

      ;
    }
    {
      (idx = 134);
      {
        ((((data)->h)[133]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 135);
      {
        ((((data)->h)[134]) = ((float)0.039380644));
      }

      ;
    }
    {
      (idx = 136);
      {
        ((((data)->h)[135]) = ((float)0.03445805));
      }

      ;
    }
    {
      (idx = 137);
      {
        ((((data)->h)[136]) = ((float)-8.4351276E-10));
      }

      ;
    }
    {
      (idx = 138);
      {
        ((((data)->h)[137]) = ((float)-0.02756644));
      }

      ;
    }
    {
      (idx = 139);
      {
        ((((data)->h)[138]) = ((float)-0.025060395));
      }

      ;
    }
    {
      (idx = 140);
      {
        ((((data)->h)[139]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 141);
      {
        ((((data)->h)[140]) = ((float)0.021204958));
      }

      ;
    }
    {
      (idx = 142);
      {
        ((((data)->h)[141]) = ((float)0.019690307));
      }

      ;
    }
    {
      (idx = 143);
      {
        ((((data)->h)[142]) = ((float)-1.4335244E-8));
      }

      ;
    }
    {
      (idx = 144);
      {
        ((((data)->h)[143]) = ((float)-0.017229032));
      }

      ;
    }
    {
      (idx = 145);
      {
        ((((data)->h)[144]) = ((float)-0.016215552));
      }

      ;
    }
    {
      (idx = 146);
      {
        ((((data)->h)[145]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 147);
      {
        ((((data)->h)[146]) = ((float)0.014508653));
      }

      ;
    }
    {
      (idx = 148);
      {
        ((((data)->h)[147]) = ((float)0.013783224));
      }

      ;
    }
    {
      (idx = 149);
      {
        ((((data)->h)[148]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 150);
      {
        ((((data)->h)[149]) = ((float)-0.0125302095));
      }

      ;
    }
    {
      (idx = 151);
      {
        ((((data)->h)[150]) = ((float)-0.011985405));
      }

      ;
    }
    {
      (idx = 152);
      {
        ((((data)->h)[151]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 153);
      {
        ((((data)->h)[152]) = ((float)0.011026581));
      }

      ;
    }
    {
      (idx = 154);
      {
        ((((data)->h)[153]) = ((float)0.010602477));
      }

      ;
    }
    {
      (idx = 155);
      {
        ((((data)->h)[154]) = ((float)-8.4351265E-10));
      }

      ;
    }
    {
      (idx = 156);
      {
        ((((data)->h)[155]) = ((float)-0.009845168));
      }

      ;
    }
    {
      (idx = 157);
      {
        ((((data)->h)[156]) = ((float)-0.009505662));
      }

      ;
    }
    {
      (idx = 158);
      {
        ((((data)->h)[157]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 159);
      {
        ((((data)->h)[158]) = ((float)0.008892397));
      }

      ;
    }
    {
      (idx = 160);
      {
        ((((data)->h)[159]) = ((float)0.008614508));
      }

      ;
    }
    {
      (idx = 161);
      {
        ((((data)->h)[160]) = ((float)-2.5373932E-8));
      }

      ;
    }
    {
      (idx = 162);
      {
        ((((data)->h)[161]) = ((float)-0.0081077805));
      }

      ;
    }
    {
      (idx = 163);
      {
        ((((data)->h)[162]) = ((float)-0.007876117));
      }

      ;
    }
    {
      (idx = 164);
      {
        ((((data)->h)[163]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 165);
      {
        ((((data)->h)[164]) = ((float)0.007450398));
      }

      ;
    }
    {
      (idx = 166);
      {
        ((((data)->h)[165]) = ((float)0.0072543286));
      }

      ;
    }
    {
      (idx = 167);
      {
        ((((data)->h)[166]) = ((float)-1.12217675E-8));
      }

      ;
    }
    {
      (idx = 168);
      {
        ((((data)->h)[167]) = ((float)-0.006891608));
      }

      ;
    }
    {
      (idx = 169);
      {
        ((((data)->h)[168]) = ((float)-0.0067235194));
      }

      ;
    }
    {
      (idx = 170);
      {
        ((((data)->h)[169]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 171);
      {
        ((((data)->h)[170]) = ((float)0.006410803));
      }

      ;
    }
    {
      (idx = 172);
      {
        ((((data)->h)[171]) = ((float)0.0062650926));
      }

      ;
    }
    {
      (idx = 173);
      {
        ((((data)->h)[172]) = ((float)-8.4351276E-10));
      }

      ;
    }
    {
      (idx = 174);
      {
        ((((data)->h)[173]) = ((float)-0.005992712));
      }

      ;
    }
    {
      (idx = 175);
      {
        ((((data)->h)[174]) = ((float)-0.005865202));
      }

      ;
    }
    {
      (idx = 176);
      {
        ((((data)->h)[175]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 177);
      {
        ((((data)->h)[176]) = ((float)0.0056258147));
      }

      ;
    }
    {
      (idx = 178);
      {
        ((((data)->h)[177]) = ((float)0.0055132858));
      }

      ;
    }
    {
      (idx = 179);
      {
        ((((data)->h)[178]) = ((float)-1.6716138E-8));
      }

      ;
    }
    {
      (idx = 180);
      {
        ((((data)->h)[179]) = ((float)-0.005301241));
      }

      ;
    }
    {
      (idx = 181);
      {
        ((((data)->h)[180]) = ((float)-0.0052012093));
      }

      ;
    }
    {
      (idx = 182);
      {
        ((((data)->h)[181]) = ((float)8.4351265E-10));
      }

      ;
    }
    {
      (idx = 183);
      {
        ((((data)->h)[182]) = ((float)0.005012086));
      }

      ;
    }
    {
      (idx = 184);
      {
        ((((data)->h)[183]) = ((float)0.0049225693));
      }

      ;
    }
    {
      (idx = 185);
      {
        ((((data)->h)[184]) = ((float)-7.944424E-9));
      }

      ;
    }
    {
      (idx = 186);
      {
        ((((data)->h)[185]) = ((float)-0.0047528436));
      }

      ;
    }
    {
      (idx = 187);
      {
        ((((data)->h)[186]) = ((float)-0.004672276));
      }

      ;
    }
    {
      (idx = 188);
      {
        ((((data)->h)[187]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 189);
      {
        ((((data)->h)[188]) = ((float)0.0045190905));
      }

      ;
    }
    {
      (idx = 190);
      {
        ((((data)->h)[189]) = ((float)0.0044462048));
      }

      ;
    }
    {
      (idx = 191);
      {
        ((((data)->h)[190]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 192);
      {
        ((((data)->h)[191]) = ((float)-0.0043072617));
      }

      ;
    }
    {
      (idx = 193);
      {
        ((((data)->h)[192]) = ((float)-0.004240992));
      }

      ;
    }
    {
      (idx = 194);
      {
        ((((data)->h)[193]) = ((float)2.5373932E-8));
      }

      ;
    }
    {
      (idx = 195);
      {
        ((((data)->h)[194]) = ((float)0.0041144025));
      }

      ;
    }
    {
      (idx = 196);
      {
        ((((data)->h)[195]) = ((float)0.0040538865));
      }

      ;
    }
    {
      (idx = 197);
      {
        ((((data)->h)[196]) = ((float)5.0224576E-9));
      }

      ;
    }
    {
      (idx = 198);
      {
        ((((data)->h)[197]) = ((float)-0.0039380733));
      }

      ;
    }
    {
      (idx = 199);
      {
        ((((data)->h)[198]) = ((float)-0.0038825925));
      }

      ;
    }
    {
      (idx = 200);
      {
        ((((data)->h)[199]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 201);
      {
        ((((data)->h)[200]) = ((float)0.0037762376));
      }

      ;
    }
    {
      (idx = 202);
      {
        ((((data)->h)[201]) = ((float)0.0037251874));
      }

      ;
    }
    {
      (idx = 203);
      {
        ((((data)->h)[202]) = ((float)-6.2402052E-9));
      }

      ;
    }
    {
      (idx = 204);
      {
        ((((data)->h)[203]) = ((float)-0.0036271624));
      }

      ;
    }
    {
      (idx = 205);
      {
        ((((data)->h)[204]) = ((float)-0.0035800475));
      }

      ;
    }
    {
      (idx = 206);
      {
        ((((data)->h)[205]) = ((float)1.12217675E-8));
      }

      ;
    }
    {
      (idx = 207);
      {
        ((((data)->h)[206]) = ((float)0.0034894247));
      }

      ;
    }
    {
      (idx = 208);
      {
        ((((data)->h)[207]) = ((float)0.0034458085));
      }

      ;
    }
    {
      (idx = 209);
      {
        ((((data)->h)[208]) = ((float)-1.5834326E-8));
      }

      ;
    }
    {
      (idx = 210);
      {
        ((((data)->h)[209]) = ((float)-0.0033617653));
      }

      ;
    }
    {
      (idx = 211);
      {
        ((((data)->h)[210]) = ((float)-0.0033212588));
      }

      ;
    }
    {
      (idx = 212);
      {
        ((((data)->h)[211]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 213);
      {
        ((((data)->h)[212]) = ((float)0.0032431171));
      }

      ;
    }
    {
      (idx = 214);
      {
        ((((data)->h)[213]) = ((float)0.0032053986));
      }

      ;
    }
    {
      (idx = 215);
      {
        ((((data)->h)[214]) = ((float)3.8088084E-9));
      }

      ;
    }
    {
      (idx = 216);
      {
        ((((data)->h)[215]) = ((float)-0.0031325584));
      }

      ;
    }
    {
      (idx = 217);
      {
        ((((data)->h)[216]) = ((float)-0.0030973493));
      }

      ;
    }
    {
      (idx = 218);
      {
        ((((data)->h)[217]) = ((float)8.4351276E-10));
      }

      ;
    }
    {
      (idx = 219);
      {
        ((((data)->h)[218]) = ((float)0.0030292897));
      }

      ;
    }
    {
      (idx = 220);
      {
        ((((data)->h)[219]) = ((float)0.0029963464));
      }

      ;
    }
    {
      (idx = 221);
      {
        ((((data)->h)[220]) = ((float)-5.1956843E-9));
      }

      ;
    }
    {
      (idx = 222);
      {
        ((((data)->h)[221]) = ((float)-0.0029325993));
      }

      ;
    }
    {
      (idx = 223);
      {
        ((((data)->h)[222]) = ((float)-0.0029017227));
      }

      ;
    }
    {
      (idx = 224);
      {
        ((((data)->h)[223]) = ((float)9.275845E-9));
      }

      ;
    }
    {
      (idx = 225);
      {
        ((((data)->h)[224]) = ((float)0.0028419027));
      }

      ;
    }
    {
      (idx = 226);
      {
        ((((data)->h)[225]) = ((float)0.0028128922));
      }

      ;
    }
    {
      (idx = 227);
      {
        ((((data)->h)[226]) = ((float)-1.3108724E-8));
      }

      ;
    }
    {
      (idx = 228);
      {
        ((((data)->h)[227]) = ((float)-0.0027566475));
      }

      ;
    }
    {
      (idx = 229);
      {
        ((((data)->h)[228]) = ((float)-0.0027293512));
      }

      ;
    }
    {
      (idx = 230);
      {
        ((((data)->h)[229]) = ((float)1.6716138E-8));
      }

      ;
    }
    {
      (idx = 231);
      {
        ((((data)->h)[230]) = ((float)0.0026763587));
      }

      ;
    }
    {
      (idx = 232);
      {
        ((((data)->h)[231]) = ((float)0.0026506179));
      }

      ;
    }
    {
      (idx = 233);
      {
        ((((data)->h)[232]) = ((float)-2.0117414E-8));
      }

      ;
    }
    {
      (idx = 234);
      {
        ((((data)->h)[233]) = ((float)-0.0026006147));
      }

      ;
    }
    {
      (idx = 235);
      {
        ((((data)->h)[234]) = ((float)-0.0025762997));
      }

      ;
    }
    {
      (idx = 236);
      {
        ((((data)->h)[235]) = ((float)8.4351265E-10));
      }

      ;
    }
    {
      (idx = 237);
      {
        ((((data)->h)[236]) = ((float)0.0025290402));
      }

      ;
    }
    {
      (idx = 238);
      {
        ((((data)->h)[237]) = ((float)0.002506035));
      }

      ;
    }
    {
      (idx = 239);
      {
        ((((data)->h)[238]) = ((float)-4.489926E-9));
      }

      ;
    }
    {
      (idx = 240);
      {
        ((((data)->h)[239]) = ((float)-0.0024612998));
      }

      ;
    }
    {
      (idx = 241);
      {
        ((((data)->h)[240]) = ((float)-0.0024395015));
      }

      ;
    }
    {
      (idx = 242);
      {
        ((((data)->h)[241]) = ((float)7.944424E-9));
      }

      ;
    }
    {
      (idx = 243);
      {
        ((((data)->h)[242]) = ((float)0.002397083));
      }

      ;
    }
    {
      (idx = 244);
      {
        ((((data)->h)[243]) = ((float)0.0023764092));
      }

      ;
    }
    {
      (idx = 245);
      {
        ((((data)->h)[244]) = ((float)-1.12217675E-8));
      }

      ;
    }
    {
      (idx = 246);
      {
        ((((data)->h)[245]) = ((float)-0.002336142));
      }

      ;
    }
    {
      (idx = 247);
      {
        ((((data)->h)[246]) = ((float)-0.002316508));
      }

      ;
    }
    {
      (idx = 248);
      {
        ((((data)->h)[247]) = ((float)1.4335244E-8));
      }

      ;
    }
    {
      (idx = 249);
      {
        ((((data)->h)[248]) = ((float)0.002278223));
      }

      ;
    }
    {
      (idx = 250);
      {
        ((((data)->h)[249]) = ((float)0.002259543));
      }

      ;
    }
    {
      (idx = 251);
      {
        ((((data)->h)[250]) = ((float)2.4471536E-9));
      }

      ;
    }
    {
      (idx = 252);
      {
        ((((data)->h)[251]) = ((float)-0.0022230966));
      }

      ;
    }
    {
      (idx = 253);
      {
        ((((data)->h)[252]) = ((float)-0.0022053027));
      }

      ;
    }
    {
      (idx = 254);
      {
        ((((data)->h)[253]) = ((float)2.0117414E-8));
      }

      ;
    }
    {
      (idx = 255);
      {
        ((((data)->h)[254]) = ((float)0.0021705935));
      }

      ;
    }
    {
      (idx = 256);
      {
        ((((data)->h)[255]) = ((float)0.0021536238));
      }

      ;
    }
    (i = 256);
  }

  ;
  set_stream_type(((data)->context), FILTER);
  set_push(((data)->context), 1);
  set_peek(((data)->context), 256);
  set_pop(((data)->context), 1);
  set_work(((data)->context), (work_fn)LowPassFilter_1_work);
}

void FloatPrinter_1_work(FloatPrinter_1 data) {
  VARS_DEFAULTB();LOCALIZE_DEFAULTB(((data)->context));
  printf("%f\n", (POP_DEFAULTB( float)));
  UNLOCALIZE_DEFAULTB(((data)->context));
}

void FloatPrinter_1_init(FloatPrinter_1 data) {
  set_stream_type(((data)->context), FILTER);
  set_push(((data)->context), 0);
  set_peek(((data)->context), 1);
  set_pop(((data)->context), 1);
  set_work(((data)->context), (work_fn)FloatPrinter_1_work);
}

void FIRProgram_1_init(FIRProgram_1 data) {
  set_stream_type(((data)->context), PIPELINE);
  set_work(((data)->context), (work_fn)hierarchical_work_1);
  data->child_0 = malloc(sizeof(_FloatSource_1));
  data->child_0->context = create_context(data->child_0);
  register_child(((data)->context), data->child_0->context);
  data->child_1 = malloc(sizeof(_LowPassFilter_1));
  data->child_1->context = create_context(data->child_1);
  register_child(((data)->context), data->child_1->context);
  data->child_2 = malloc(sizeof(_FloatPrinter_1));
  data->child_2->context = create_context(data->child_2);
  register_child(((data)->context), data->child_2->context);

  ;

  ;

  ;
  FloatSource_1_init(((data)->child_0));
  LowPassFilter_1_init(((data)->child_1));
  FloatPrinter_1_init(((data)->child_2));
  create_tape(((data)->child_0)->context, ((data)->child_1)->context, sizeof(float), 256);
  create_tape(((data)->child_1)->context, ((data)->child_2)->context, sizeof(float), 1);
}
