#!/bin/sh

nohup make fir-results | mhmail aalamb@mit.edu -s "fir results ready"
nohup make target-results | mhmail aalamb@mit.edu -s "target results ready"
nohup make filterbank-results | mhmail aalamb@mit.edu -s "filterbank results ready"
nohup make sampling-results | mhmail aalamb@mit.edu -s "sampling results ready"
nohup make test-results | mhmail aalamb@mit.edu -s "test results ready"


# longer tests
nohup make fm-results | mhmail aalamb@mit.edu -s "fm results ready"
nohup make beamformer-results | mhmail aalamb@mit.edu -s "beamformer results ready"
